/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoolife;

import zoolife.ventanas.JDatosCliente;

/**
 *
 * @author Benjamín Igor
 * @author Emilio Contreras
 * @author Pablo Martínez
 */
//Clase Zoolife
public class Zoolife {
//Main
    public static void main(String[] args) {
        JDatosCliente cliente = new JDatosCliente();
        cliente.setVisible(true);
    }
}
